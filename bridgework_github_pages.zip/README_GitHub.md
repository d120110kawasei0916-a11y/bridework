# BridgeWork on GitHub Pages（Project Pages 版）

この最小セット（`index.html` / `share.html`）を **新しいリポジトリ** に配置して、
GitHub Pages を有効化すると公開できます。既にユーザーサイトがある場合でもOK（Project Pagesとして増やせます）。

## 手順（最短）
1. 新規リポ作成（例：`bridgework`）
2. 本ZIPの `index.html` と `share.html` をアップロードして Commit
3. リポの **Settings → Pages** を開く
   - **Source**: `Deploy from a branch`
   - **Branch**: `main`  /  **`/(root)`**
   - **Save**
4. しばらくすると公開URLが発行されます：
   `https://<ユーザー名>.github.io/<リポジトリ名>/`

### QR 共有ページ
`share.html?u=<公開URL>` を開くと、QRコードとコピー/共有UIが表示されます。
例：`https://<ユーザー名>.github.io/<リポ>/share.html?u=https://<ユーザー名>.github.io/<リポ>/`

※ `share.html` のQRは Google Chart API を使用（ネット接続が必要）。
